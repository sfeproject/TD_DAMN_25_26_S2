package com.sphere

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.sphere.databinding.ActivityMainBinding
import kotlin.math.PI
import kotlin.math.pow


class MainActivity : AppCompatActivity() {
    private lateinit var amb : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initGraphique()
    }
    private fun initGraphique() {
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)
        ajouterEcouteurs()
    }
    private fun ajouterEcouteurs() {
        amb.btnCalculer.setOnClickListener { calculer() }
        amb.btnPeser.setOnClickListener { peser() }
    }
    private fun calculer() {
        if(amb.etRayon.text.toString().isNotEmpty()){
            val rayon:Double=amb.etRayon.text.toString().toDouble()
            val aire:Double=4*PI*rayon.pow(2)
            val volume:Double=4/3*PI*rayon.pow(3)
            amb.etAire.setText("%.2f".format(aire))
            amb.etVolume.setText("%.2f".format(volume))

        }else{
            Toast.makeText(this,"Remplir le rayon SVP!", Toast.LENGTH_LONG).show()
        }

    }
    private fun peser() {
        if(amb.etVolume.text.toString().isNotEmpty()
            && amb.etMasseVolumique.text.toString().isNotEmpty()){
            val volume:Double=amb.etVolume.text.toString().toDouble()
            val masseVolumique:Double=amb.etMasseVolumique.text.toString().toDouble()
            val poids: Double=volume*masseVolumique
            amb.etPoids.setText("%.2f".format(poids))

        }else{
            Toast.makeText(this,"Remplir Tous les champs SVP!", Toast.LENGTH_LONG).show()
        }

    }


}